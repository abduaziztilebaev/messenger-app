import React, { createContext, useContext, useState, useEffect } from 'react';
import { Conversation, Message } from '../types';
import { conversations as mockConversations } from '../utils/mockData';

interface MessageContextType {
  conversations: Conversation[];
  activeConversation: Conversation | null;
  setActiveConversation: (conversationId: string) => void;
  sendMessage: (text: string, replyToId?: string) => void;
  markAsRead: (messageId: string) => void;
  searchConversations: (query: string) => Conversation[];
}

const MessageContext = createContext<MessageContextType | undefined>(undefined);

export const MessageProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [conversations, setConversations] = useState<Conversation[]>(() => {
    const savedConversations = localStorage.getItem('conversations');
    return savedConversations ? JSON.parse(savedConversations) : mockConversations;
  });
  
  const [activeConversation, setActiveConversationState] = useState<Conversation | null>(null);
  
  // Save conversations to localStorage when they change
  useEffect(() => {
    localStorage.setItem('conversations', JSON.stringify(conversations));
  }, [conversations]);
  
  const setActiveConversation = (conversationId: string) => {
    const conversation = conversations.find(c => c.id === conversationId) || null;
    setActiveConversationState(conversation);
    
    // Mark all messages as read when opening a conversation
    if (conversation) {
      const updatedConversations = conversations.map(c => {
        if (c.id === conversationId) {
          const updatedMessages = c.messages.map(m => {
            if (!m.read) {
              return { ...m, read: true };
            }
            return m;
          });
          
          return {
            ...c,
            messages: updatedMessages,
            unreadCount: 0
          };
        }
        return c;
      });
      
      setConversations(updatedConversations);
    }
  };
  
  const sendMessage = (text: string, replyToId?: string) => {
    if (!activeConversation) return;
    
    const newMessage: Message = {
      id: `msg-${Date.now()}`,
      senderId: 'current-user',
      text,
      timestamp: new Date().toISOString(),
      read: false,
      replyTo: replyToId
    };
    
    const updatedConversations = conversations.map(conversation => {
      if (conversation.id === activeConversation.id) {
        return {
          ...conversation,
          messages: [...conversation.messages, newMessage],
          lastMessageTimestamp: newMessage.timestamp
        };
      }
      return conversation;
    });
    
    setConversations(updatedConversations);
    
    // Update active conversation
    setActiveConversationState(prev => {
      if (!prev) return null;
      return {
        ...prev,
        messages: [...prev.messages, newMessage],
        lastMessageTimestamp: newMessage.timestamp
      };
    });
    
    // Simulate a reply after a short delay
    setTimeout(() => {
      const replyMessage: Message = {
        id: `msg-${Date.now() + 1}`,
        senderId: activeConversation.participants.find(p => p.id !== 'current-user')?.id || '',
        text: 'Thanks for your message! I\'ll get back to you soon.',
        timestamp: new Date().toISOString(),
        read: false,
      };
      
      const updatedWithReply = conversations.map(conversation => {
        if (conversation.id === activeConversation.id) {
          return {
            ...conversation,
            messages: [...conversation.messages, newMessage, replyMessage],
            lastMessageTimestamp: replyMessage.timestamp,
            unreadCount: conversation.unreadCount + 1
          };
        }
        return conversation;
      });
      
      setConversations(updatedWithReply);
      
      // Update active conversation
      setActiveConversationState(prev => {
        if (!prev) return null;
        return {
          ...prev,
          messages: [...prev.messages, replyMessage],
          lastMessageTimestamp: replyMessage.timestamp,
          unreadCount: 0 // When active, mark as read
        };
      });
    }, 2000);
  };
  
  const markAsRead = (messageId: string) => {
    if (!activeConversation) return;
    
    const updatedConversations = conversations.map(conversation => {
      if (conversation.id === activeConversation.id) {
        const updatedMessages = conversation.messages.map(message => {
          if (message.id === messageId) {
            return { ...message, read: true };
          }
          return message;
        });
        
        const unreadCount = updatedMessages.filter(m => !m.read).length;
        
        return {
          ...conversation,
          messages: updatedMessages,
          unreadCount
        };
      }
      return conversation;
    });
    
    setConversations(updatedConversations);
  };
  
  const searchConversations = (query: string): Conversation[] => {
    if (!query.trim()) return conversations;
    
    const lowerCaseQuery = query.toLowerCase();
    
    return conversations.filter(conversation => {
      // Search in participant names
      const participantMatch = conversation.participants.some(
        participant => participant.name.toLowerCase().includes(lowerCaseQuery)
      );
      
      // Search in messages
      const messageMatch = conversation.messages.some(
        message => message.text.toLowerCase().includes(lowerCaseQuery)
      );
      
      return participantMatch || messageMatch;
    });
  };
  
  return (
    <MessageContext.Provider 
      value={{ 
        conversations, 
        activeConversation, 
        setActiveConversation, 
        sendMessage, 
        markAsRead,
        searchConversations
      }}
    >
      {children}
    </MessageContext.Provider>
  );
};

export const useMessages = () => {
  const context = useContext(MessageContext);
  if (context === undefined) {
    throw new Error('useMessages must be used within a MessageProvider');
  }
  return context;
};