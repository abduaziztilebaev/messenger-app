import React, { createContext, useContext, useState, useEffect } from 'react';
import { User, UserSettings } from '../types';
import { currentUser, defaultUserSettings } from '../utils/mockData';

interface UserProfile {
  name: string;
  email: string;
  bio: string;
}

interface UserContextType {
  user: User;
  settings: UserSettings;
  updateSettings: (newSettings: Partial<UserSettings> & { profile?: UserProfile }) => void;
  updatePrivacySettings: (field: keyof UserSettings['privacy'], value: boolean) => void;
  updateNotificationSettings: (field: keyof UserSettings['notifications'], value: boolean) => void;
  updateLanguage: (language: UserSettings['language']) => void;
  updateFontSize: (fontSize: UserSettings['fontSize']) => void;
  updateProfile: (profile: UserProfile) => void;
}

const UserContext = createContext<UserContextType | undefined>(undefined);

export const UserProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User>(currentUser);
  const [settings, setSettings] = useState<UserSettings>(() => {
    const savedSettings = localStorage.getItem('userSettings');
    return savedSettings ? JSON.parse(savedSettings) : defaultUserSettings;
  });
  
  // Save settings to localStorage when they change
  useEffect(() => {
    localStorage.setItem('userSettings', JSON.stringify(settings));
  }, [settings]);
  
  const updateSettings = (newSettings: Partial<UserSettings> & { profile?: UserProfile }) => {
    if (newSettings.profile) {
      setUser(prev => ({
        ...prev,
        name: newSettings.profile.name
      }));
    }
    setSettings(prev => ({ ...prev, ...newSettings }));
  };
  
  const updateProfile = (profile: UserProfile) => {
    setUser(prev => ({
      ...prev,
      name: profile.name
    }));
    setSettings(prev => ({
      ...prev,
      profile
    }));
  };
  
  const updatePrivacySettings = (field: keyof UserSettings['privacy'], value: boolean) => {
    setSettings(prev => ({
      ...prev,
      privacy: {
        ...prev.privacy,
        [field]: value
      }
    }));
  };
  
  const updateNotificationSettings = (field: keyof UserSettings['notifications'], value: boolean) => {
    setSettings(prev => ({
      ...prev,
      notifications: {
        ...prev.notifications,
        [field]: value
      }
    }));
  };
  
  const updateLanguage = (language: UserSettings['language']) => {
    setSettings(prev => ({ ...prev, language }));
  };
  
  const updateFontSize = (fontSize: UserSettings['fontSize']) => {
    setSettings(prev => ({ ...prev, fontSize }));
  };
  
  return (
    <UserContext.Provider 
      value={{ 
        user, 
        settings, 
        updateSettings, 
        updatePrivacySettings, 
        updateNotificationSettings,
        updateLanguage,
        updateFontSize,
        updateProfile
      }}
    >
      {children}
    </UserContext.Provider>
  );
};

export const useUser = () => {
  const context = useContext(UserContext);
  if (context === undefined) {
    throw new Error('useUser must be used within a UserProvider');
  }
  return context;
};