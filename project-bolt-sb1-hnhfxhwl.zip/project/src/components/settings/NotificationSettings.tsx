import React from 'react';
import { useUser } from '../../contexts/UserContext';
import Toggle from '../ui/Toggle';
import { Bell } from 'lucide-react';

const NotificationSettings: React.FC = () => {
  const { settings, updateNotificationSettings } = useUser();
  const { notifications } = settings;
  
  return (
    <div className="space-y-6">
      <div className="flex items-center space-x-3">
        <div className="p-2 bg-amber-100 dark:bg-amber-900/30 rounded-full">
          <Bell className="w-5 h-5 text-amber-600 dark:text-amber-400" />
        </div>
        <h2 className="text-lg font-medium text-gray-900 dark:text-gray-100">Notifications</h2>
      </div>
      
      <div className="space-y-4">
        <Toggle
          enabled={notifications.messageNotifications}
          onChange={(enabled) => updateNotificationSettings('messageNotifications', enabled)}
          label="Message notifications"
          description="Receive notifications when you get new messages"
        />
        
        <Toggle
          enabled={notifications.soundEnabled}
          onChange={(enabled) => updateNotificationSettings('soundEnabled', enabled)}
          label="Sound"
          description="Play sound when receiving messages"
        />
        
        <Toggle
          enabled={notifications.notifyWhenMentioned}
          onChange={(enabled) => updateNotificationSettings('notifyWhenMentioned', enabled)}
          label="Mentions"
          description="Receive notifications when you're mentioned"
        />
      </div>
      
      <div className="pt-4">
        <h3 className="text-sm font-medium text-gray-900 dark:text-gray-100 mb-2">
          Do Not Disturb
        </h3>
        
        <div className="bg-gray-50 dark:bg-gray-800 rounded-lg p-3">
          <label className="flex items-center">
            <input
              type="checkbox"
              className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 dark:border-gray-700 rounded"
            />
            <span className="ml-2 text-sm text-gray-700 dark:text-gray-300">
              Enable Do Not Disturb
            </span>
          </label>
          
          <div className="mt-3 grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs text-gray-500 dark:text-gray-400">
                From
              </label>
              <select className="mt-1 block w-full pl-3 pr-10 py-1.5 text-sm border border-gray-300 dark:border-gray-700 rounded-md bg-white dark:bg-gray-900">
                <option>8:00 PM</option>
                <option>9:00 PM</option>
                <option>10:00 PM</option>
                <option>11:00 PM</option>
                <option>12:00 AM</option>
              </select>
            </div>
            
            <div>
              <label className="block text-xs text-gray-500 dark:text-gray-400">
                To
              </label>
              <select className="mt-1 block w-full pl-3 pr-10 py-1.5 text-sm border border-gray-300 dark:border-gray-700 rounded-md bg-white dark:bg-gray-900">
                <option>6:00 AM</option>
                <option>7:00 AM</option>
                <option>8:00 AM</option>
                <option>9:00 AM</option>
                <option>10:00 AM</option>
              </select>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default NotificationSettings;