import React from 'react';
import { useTheme } from '../../contexts/ThemeContext';
import { Sun, Moon, MonitorSmartphone } from 'lucide-react';

const ThemeSettings: React.FC = () => {
  const { theme, setTheme } = useTheme();
  
  return (
    <div className="space-y-6">
      <div className="flex items-center space-x-3">
        <div className="p-2 bg-purple-100 dark:bg-purple-900/30 rounded-full">
          <MonitorSmartphone className="w-5 h-5 text-purple-600 dark:text-purple-400" />
        </div>
        <h2 className="text-lg font-medium text-gray-900 dark:text-gray-100">Appearance</h2>
      </div>
      
      <div className="grid grid-cols-3 gap-3">
        <button
          onClick={() => setTheme('light')}
          className={`flex flex-col items-center p-4 rounded-lg transition-colors ${
            theme === 'light'
              ? 'bg-blue-50 dark:bg-blue-900/20 ring-2 ring-blue-500'
              : 'bg-gray-100 dark:bg-gray-800 hover:bg-gray-200 dark:hover:bg-gray-700'
          }`}
        >
          <Sun className="w-6 h-6 mb-2 text-yellow-500" />
          <span className="text-sm font-medium text-gray-900 dark:text-gray-100">Light</span>
        </button>
        
        <button
          onClick={() => setTheme('dark')}
          className={`flex flex-col items-center p-4 rounded-lg transition-colors ${
            theme === 'dark'
              ? 'bg-blue-50 dark:bg-blue-900/20 ring-2 ring-blue-500'
              : 'bg-gray-100 dark:bg-gray-800 hover:bg-gray-200 dark:hover:bg-gray-700'
          }`}
        >
          <Moon className="w-6 h-6 mb-2 text-indigo-500" />
          <span className="text-sm font-medium text-gray-900 dark:text-gray-100">Dark</span>
        </button>
        
        <button
          onClick={() => setTheme('system')}
          className={`flex flex-col items-center p-4 rounded-lg transition-colors ${
            theme === 'system'
              ? 'bg-blue-50 dark:bg-blue-900/20 ring-2 ring-blue-500'
              : 'bg-gray-100 dark:bg-gray-800 hover:bg-gray-200 dark:hover:bg-gray-700'
          }`}
        >
          <MonitorSmartphone className="w-6 h-6 mb-2 text-gray-600 dark:text-gray-400" />
          <span className="text-sm font-medium text-gray-900 dark:text-gray-100">System</span>
        </button>
      </div>
      
      <div className="pt-4">
        <h3 className="text-sm font-medium text-gray-900 dark:text-gray-100 mb-2">
          Color Scheme
        </h3>
        
        <div className="grid grid-cols-6 gap-2">
          {['#3B82F6', '#8B5CF6', '#EC4899', '#10B981', '#F59E0B', '#EF4444'].map((color) => (
            <button
              key={color}
              className="w-full aspect-square rounded-md border-2 border-transparent hover:scale-110 transition-transform focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
              style={{ backgroundColor: color }}
              aria-label={`Color ${color}`}
            />
          ))}
        </div>
      </div>
    </div>
  );
};

export default ThemeSettings;