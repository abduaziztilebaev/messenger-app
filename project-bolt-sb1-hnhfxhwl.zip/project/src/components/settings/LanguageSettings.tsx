import React from 'react';
import { useUser } from '../../contexts/UserContext';
import Select from '../ui/Select';
import { languageOptions } from '../../utils/mockData';
import { Globe } from 'lucide-react';

const LanguageSettings: React.FC = () => {
  const { settings, updateLanguage, updateFontSize: updateUserFontSize } = useUser();
  
  const updateFontSize = (fontSize: 'small' | 'medium' | 'large') => {
    updateUserFontSize(fontSize);
    
    // Apply font size to body
    const sizeClasses = {
      small: 'text-sm',
      medium: 'text-base',
      large: 'text-lg',
    };
    
    document.body.classList.remove('text-sm', 'text-base', 'text-lg');
    document.body.classList.add(sizeClasses[fontSize]);
  };
  
  return (
    <div className="space-y-6">
      <div className="flex items-center space-x-3">
        <div className="p-2 bg-blue-100 dark:bg-blue-900/30 rounded-full">
          <Globe className="w-5 h-5 text-blue-600 dark:text-blue-400" />
        </div>
        <h2 className="text-lg font-medium text-gray-900 dark:text-gray-100">Language & Display</h2>
      </div>
      
      <div className="space-y-4">
        <div>
          <p className="text-sm text-gray-500 dark:text-gray-400 mb-4">
            Choose your preferred language and display settings
          </p>
          
          <Select
            options={languageOptions}
            value={settings.language}
            onChange={updateLanguage}
            label="Display Language"
          />
        </div>
        
        <div className="pt-4">
          <h3 className="text-sm font-medium text-gray-900 dark:text-gray-100 mb-2">
            Text Size
          </h3>
          
          <div className="flex items-center space-x-4">
            <button
              onClick={() => updateFontSize('small')}
              className={`px-3 py-1.5 rounded-md text-sm transition-colors ${
                settings.fontSize === 'small'
                  ? 'bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400'
                  : 'bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700'
              }`}
            >
              Small
            </button>
            
            <button
              onClick={() => updateFontSize('medium')}
              className={`px-3 py-1.5 rounded-md text-sm transition-colors ${
                settings.fontSize === 'medium'
                  ? 'bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400'
                  : 'bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700'
              }`}
            >
              Medium
            </button>
            
            <button
              onClick={() => updateFontSize('large')}
              className={`px-3 py-1.5 rounded-md text-sm transition-colors ${
                settings.fontSize === 'large'
                  ? 'bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400'
                  : 'bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700'
              }`}
            >
              Large
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LanguageSettings;