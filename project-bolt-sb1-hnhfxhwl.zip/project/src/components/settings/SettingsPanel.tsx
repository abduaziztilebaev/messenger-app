import React, { useState } from 'react';
import PrivacySettings from './PrivacySettings';
import LanguageSettings from './LanguageSettings';
import NotificationSettings from './NotificationSettings';
import ThemeSettings from './ThemeSettings';
import { Shield, Globe, Bell, MonitorSmartphone, User, X, Camera } from 'lucide-react';
import Avatar from '../ui/Avatar';
import { useUser } from '../../contexts/UserContext';
import Button from '../ui/Button';

interface SettingsPanelProps {
  onClose: () => void;
}

type SettingsTab = 'profile' | 'privacy' | 'language' | 'notifications' | 'theme';

const SettingsPanel: React.FC<SettingsPanelProps> = ({ onClose }) => {
  const [activeTab, setActiveTab] = useState<SettingsTab>('profile');
  const { user, updateProfile } = useUser();
  const [formData, setFormData] = useState({
    name: user.name,
    email: 'user@example.com',
    bio: '',
  });
  const [isSaving, setIsSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);
  
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    setSaveSuccess(false);
  };
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 500));
      updateProfile(formData);
      setSaveSuccess(true);
    } catch (error) {
      console.error('Failed to save profile:', error);
    } finally {
      setIsSaving(false);
    }
  };
  
  const tabs = [
    { id: 'profile', label: 'Profile', icon: <User /> },
    { id: 'privacy', label: 'Privacy', icon: <Shield /> },
    { id: 'language', label: 'Language', icon: <Globe /> },
    { id: 'notifications', label: 'Notifications', icon: <Bell /> },
    { id: 'theme', label: 'Theme', icon: <MonitorSmartphone /> },
  ];
  
  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-gray-500 bg-opacity-75 flex items-center justify-center">
      <div className="bg-white dark:bg-gray-900 rounded-lg shadow-xl max-w-4xl w-full max-h-[90vh] flex flex-col">
        <div className="flex items-center justify-between p-4 border-b border-gray-200 dark:border-gray-800">
          <h2 className="text-xl font-semibold text-gray-900 dark:text-gray-100">Settings</h2>
          <button
            onClick={onClose}
            className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800 text-gray-500 dark:text-gray-400"
          >
            <X size={20} />
          </button>
        </div>
        
        <div className="flex flex-1 overflow-hidden">
          {/* Sidebar */}
          <div className="w-64 border-r border-gray-200 dark:border-gray-800 bg-gray-50 dark:bg-gray-900">
            <div className="p-4 border-b border-gray-200 dark:border-gray-800">
              <div className="flex items-center space-x-3">
                <Avatar
                  src={user.avatar}
                  alt={user.name}
                  size="large"
                  status={user.status}
                />
                <div>
                  <h3 className="font-medium text-gray-900 dark:text-gray-100">{user.name}</h3>
                  <p className="text-xs text-gray-500 dark:text-gray-400">
                    {user.status === 'online' ? 'Online' : user.status === 'away' ? 'Away' : 'Offline'}
                  </p>
                </div>
              </div>
            </div>
            
            <nav className="p-2">
              <ul className="space-y-1">
                {tabs.map((tab) => (
                  <li key={tab.id}>
                    <button
                      onClick={() => setActiveTab(tab.id as SettingsTab)}
                      className={`flex items-center w-full px-3 py-2 text-sm rounded-lg transition-colors ${
                        activeTab === tab.id
                          ? 'bg-blue-100 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400'
                          : 'text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800'
                      }`}
                    >
                      <span className="mr-3">{tab.icon}</span>
                      {tab.label}
                    </button>
                  </li>
                ))}
              </ul>
            </nav>
          </div>
          
          {/* Content */}
          <div className="flex-1 p-6 overflow-y-auto">
            {activeTab === 'profile' && (
              <div className="space-y-6">
                <div className="flex items-center space-x-3">
                  <div className="p-2 bg-blue-100 dark:bg-blue-900/30 rounded-full">
                    <User className="w-5 h-5 text-blue-600 dark:text-blue-400" />
                  </div>
                  <h2 className="text-lg font-medium text-gray-900 dark:text-gray-100">Profile</h2>
                </div>
                
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="flex flex-col items-center py-6">
                    <div className="relative group">
                      <Avatar
                        src={user.avatar}
                        alt={user.name}
                        size="large"
                        status={user.status}
                      />
                      <button
                        type="button"
                        className="absolute inset-0 flex items-center justify-center bg-black bg-opacity-50 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                      >
                        <Camera className="w-5 h-5 text-white" />
                      </button>
                    </div>
                  </div>
                  
                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                        Display Name
                      </label>
                      <input
                        type="text"
                        name="name"
                        value={formData.name}
                        onChange={handleInputChange}
                        className="w-full px-3 py-2 border border-gray-300 dark:border-gray-700 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 bg-white dark:bg-gray-800 text-gray-900 dark:text-gray-100"
                        required
                      />
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                        Email
                      </label>
                      <input
                        type="email"
                        name="email"
                        value={formData.email}
                        onChange={handleInputChange}
                        className="w-full px-3 py-2 border border-gray-300 dark:border-gray-700 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 bg-white dark:bg-gray-800 text-gray-900 dark:text-gray-100"
                        required
                      />
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                        Bio
                      </label>
                      <textarea
                        name="bio"
                        value={formData.bio}
                        onChange={handleInputChange}
                        rows={3}
                        className="w-full px-3 py-2 border border-gray-300 dark:border-gray-700 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 bg-white dark:bg-gray-800 text-gray-900 dark:text-gray-100"
                        placeholder="Write a short bio..."
                      />
                    </div>
                  </div>
                  
                  <div className="pt-4 flex items-center justify-between">
                    {saveSuccess && (
                      <p className="text-sm text-green-600 dark:text-green-400">
                        Changes saved successfully!
                      </p>
                    )}
                    <div className="ml-auto">
                      <Button
                        type="submit"
                        variant="primary"
                        disabled={isSaving}
                      >
                        {isSaving ? 'Saving...' : 'Save Changes'}
                      </Button>
                    </div>
                  </div>
                </form>
              </div>
            )}
            
            {activeTab === 'privacy' && <PrivacySettings />}
            {activeTab === 'language' && <LanguageSettings />}
            {activeTab === 'notifications' && <NotificationSettings />}
            {activeTab === 'theme' && <ThemeSettings />}
          </div>
        </div>
      </div>
    </div>
  );
};

export default SettingsPanel;