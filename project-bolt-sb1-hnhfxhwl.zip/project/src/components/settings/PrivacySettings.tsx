import React from 'react';
import { useUser } from '../../contexts/UserContext';
import Toggle from '../ui/Toggle';
import { Shield } from 'lucide-react';

const PrivacySettings: React.FC = () => {
  const { settings, updatePrivacySettings } = useUser();
  const { privacy } = settings;
  
  return (
    <div className="space-y-6">
      <div className="flex items-center space-x-3">
        <div className="p-2 bg-indigo-100 dark:bg-indigo-900/30 rounded-full">
          <Shield className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
        </div>
        <h2 className="text-lg font-medium text-gray-900 dark:text-gray-100">Privacy</h2>
      </div>
      
      <div className="space-y-4">
        <Toggle
          enabled={privacy.showReadReceipts}
          onChange={(enabled) => updatePrivacySettings('showReadReceipts', enabled)}
          label="Read receipts"
          description="Let others know when you've read their messages"
        />
        
        <Toggle
          enabled={privacy.showLastSeen}
          onChange={(enabled) => updatePrivacySettings('showLastSeen', enabled)}
          label="Last seen"
          description="Let others know when you were last online"
        />
        
        <Toggle
          enabled={privacy.showActiveStatus}
          onChange={(enabled) => updatePrivacySettings('showActiveStatus', enabled)}
          label="Active status"
          description="Show when you're actively using the app"
        />
      </div>
      
      <div className="pt-4">
        <h3 className="text-sm font-medium text-gray-900 dark:text-gray-100 mb-2">
          Who can message you
        </h3>
        
        <div className="space-y-2">
          <label className="flex items-center">
            <input
              type="radio"
              name="message-privacy"
              className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 dark:border-gray-700"
              defaultChecked
            />
            <span className="ml-2 text-sm text-gray-700 dark:text-gray-300">Everyone</span>
          </label>
          
          <label className="flex items-center">
            <input
              type="radio"
              name="message-privacy"
              className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 dark:border-gray-700"
            />
            <span className="ml-2 text-sm text-gray-700 dark:text-gray-300">Contacts only</span>
          </label>
        </div>
      </div>
    </div>
  );
};

export default PrivacySettings;