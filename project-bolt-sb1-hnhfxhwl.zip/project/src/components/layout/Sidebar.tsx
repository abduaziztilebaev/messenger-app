import React, { useState } from 'react';
import { Search, Settings, PlusCircle } from 'lucide-react';
import ConversationList from '../chat/ConversationList';
import { useMessages } from '../../contexts/MessageContext';
import Avatar from '../ui/Avatar';
import { useUser } from '../../contexts/UserContext';
import { useTheme } from '../../contexts/ThemeContext';

interface SidebarProps {
  onSettingsClick: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ onSettingsClick }) => {
  const { user } = useUser();
  const { isDarkMode } = useTheme();
  const { conversations, searchConversations } = useMessages();
  const [searchQuery, setSearchQuery] = useState('');
  const [filteredConversations, setFilteredConversations] = useState(conversations);
  
  const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    const query = e.target.value;
    setSearchQuery(query);
    setFilteredConversations(searchConversations(query));
  };
  
  return (
    <div className="w-full h-full flex flex-col bg-gray-50 dark:bg-gray-900 border-r border-gray-200 dark:border-gray-800">
      {/* Header */}
      <div className="p-4 border-b border-gray-200 dark:border-gray-800 flex justify-between items-center">
        <div className="flex items-center space-x-3">
          <Avatar src={user.avatar} alt={user.name} status={user.status} />
          <div>
            <h2 className="font-semibold text-gray-900 dark:text-gray-100">{user.name}</h2>
            <p className="text-xs text-gray-500 dark:text-gray-400">
              {user.status === 'online' ? 'Active now' : 'Away'}
            </p>
          </div>
        </div>
        <button
          onClick={onSettingsClick}
          className="p-2 rounded-full hover:bg-gray-200 dark:hover:bg-gray-800 text-gray-500 dark:text-gray-400"
        >
          <Settings size={20} />
        </button>
      </div>
      
      {/* Search */}
      <div className="p-4">
        <div className="relative">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Search size={16} className="text-gray-400" />
          </div>
          <input
            type="text"
            placeholder="Search conversations"
            value={searchQuery}
            onChange={handleSearch}
            className="block w-full pl-10 pr-3 py-2 border border-gray-300 dark:border-gray-700 rounded-lg bg-white dark:bg-gray-800 text-gray-900 dark:text-gray-100 placeholder-gray-500 dark:placeholder-gray-400 focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500 text-sm"
          />
        </div>
      </div>
      
      {/* New Chat Button */}
      <div className="px-4 mb-2">
        <button className="flex items-center justify-center w-full py-2 px-4 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors text-sm font-medium">
          <PlusCircle size={16} className="mr-2" />
          New Conversation
        </button>
      </div>
      
      {/* Conversations */}
      <div className="flex-1 overflow-y-auto">
        <ConversationList conversations={filteredConversations} />
      </div>
    </div>
  );
};

export default Sidebar;