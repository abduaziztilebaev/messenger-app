import React from 'react';

interface AvatarProps {
  src: string;
  alt: string;
  size?: 'small' | 'medium' | 'large';
  status?: 'online' | 'offline' | 'away';
}

const Avatar: React.FC<AvatarProps> = ({ 
  src, 
  alt, 
  size = 'medium',
  status
}) => {
  const sizeClasses = {
    small: 'w-8 h-8',
    medium: 'w-10 h-10',
    large: 'w-12 h-12'
  };
  
  const statusColors = {
    online: 'bg-green-500',
    offline: 'bg-gray-400',
    away: 'bg-yellow-500'
  };
  
  return (
    <div className="relative">
      <img 
        src={src} 
        alt={alt} 
        className={`${sizeClasses[size]} rounded-full object-cover border-2 border-white dark:border-gray-800`}
      />
      
      {status && (
        <span 
          className={`absolute bottom-0 right-0 block ${sizeClasses.small === sizeClasses[size] ? 'w-2.5 h-2.5' : 'w-3 h-3'} ${statusColors[status]} rounded-full ring-2 ring-white dark:ring-gray-800`}
        />
      )}
    </div>
  );
};

export default Avatar;