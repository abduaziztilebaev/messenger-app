import React from 'react';
import { Conversation } from '../../types';
import Avatar from '../ui/Avatar';
import { formatDistanceToNow } from '../../utils/dateUtils';

interface ConversationItemProps {
  conversation: Conversation;
  isActive: boolean;
  onClick: () => void;
}

const ConversationItem: React.FC<ConversationItemProps> = ({
  conversation,
  isActive,
  onClick,
}) => {
  // Find the other participant (not the current user)
  const otherParticipant = conversation.participants.find(
    (p) => p.id !== 'current-user'
  );

  if (!otherParticipant) return null;

  // Get the last message
  const lastMessage = conversation.messages[conversation.messages.length - 1];
  
  // Format the timestamp
  const timeAgo = lastMessage ? formatDistanceToNow(new Date(lastMessage.timestamp)) : '';

  return (
    <div
      className={`px-4 py-3 flex items-center cursor-pointer transition-colors ${
        isActive
          ? 'bg-blue-50 dark:bg-blue-900/20'
          : 'hover:bg-gray-100 dark:hover:bg-gray-800/50'
      }`}
      onClick={onClick}
    >
      <Avatar
        src={otherParticipant.avatar}
        alt={otherParticipant.name}
        status={otherParticipant.status}
      />
      
      <div className="ml-3 flex-1 min-w-0">
        <div className="flex justify-between items-baseline">
          <h3 className="text-sm font-medium text-gray-900 dark:text-gray-100 truncate">
            {otherParticipant.name}
          </h3>
          <span className="text-xs text-gray-500 dark:text-gray-400 ml-1 whitespace-nowrap">
            {timeAgo}
          </span>
        </div>
        
        <div className="flex items-center">
          <p className="text-xs text-gray-500 dark:text-gray-400 truncate">
            {lastMessage?.text || 'Start a conversation'}
          </p>
          
          {conversation.unreadCount > 0 && (
            <span className="ml-2 inline-flex items-center justify-center w-5 h-5 text-xs font-bold text-white bg-blue-600 rounded-full">
              {conversation.unreadCount}
            </span>
          )}
        </div>
      </div>
    </div>
  );
};

export default ConversationItem;