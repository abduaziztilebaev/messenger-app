import React, { useRef, useEffect, useState } from 'react';
import MessageBubble from './MessageBubble';
import MessageInput from './MessageInput';
import { useMessages } from '../../contexts/MessageContext';
import { Message } from '../../types';
import Avatar from '../ui/Avatar';
import { Phone, Video, Info } from 'lucide-react';

const ChatWindow: React.FC = () => {
  const { activeConversation, sendMessage } = useMessages();
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const [replyingTo, setReplyingTo] = useState<string | null>(null);
  
  // Scroll to bottom when messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [activeConversation?.messages]);
  
  if (!activeConversation) {
    return (
      <div className="flex-1 flex items-center justify-center bg-gray-50 dark:bg-gray-900">
        <div className="text-center">
          <h3 className="text-lg font-medium text-gray-700 dark:text-gray-300">
            Select a conversation
          </h3>
          <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
            Choose a conversation from the sidebar to start chatting
          </p>
        </div>
      </div>
    );
  }
  
  const otherParticipant = activeConversation.participants.find(p => p.id !== 'current-user');
  
  if (!otherParticipant) return null;
  
  const handleSendMessage = (text: string) => {
    sendMessage(text, replyingTo || undefined);
    setReplyingTo(null);
  };
  
  const handleReplyToMessage = (messageId: string) => {
    setReplyingTo(messageId);
  };
  
  // Group messages by date
  const groupMessagesByDate = (messages: Message[]) => {
    const groups: { [date: string]: Message[] } = {};
    
    messages.forEach(message => {
      const date = new Date(message.timestamp).toLocaleDateString();
      if (!groups[date]) {
        groups[date] = [];
      }
      groups[date].push(message);
    });
    
    return groups;
  };
  
  const messageGroups = groupMessagesByDate(activeConversation.messages);
  
  return (
    <div className="flex-1 flex flex-col h-full bg-white dark:bg-gray-900">
      {/* Chat header */}
      <div className="flex items-center justify-between px-4 py-3 border-b border-gray-200 dark:border-gray-800">
        <div className="flex items-center">
          <Avatar
            src={otherParticipant.avatar}
            alt={otherParticipant.name}
            status={otherParticipant.status}
          />
          <div className="ml-3">
            <h2 className="text-sm font-medium text-gray-900 dark:text-gray-100">
              {otherParticipant.name}
            </h2>
            <p className="text-xs text-gray-500 dark:text-gray-400">
              {otherParticipant.status === 'online'
                ? 'Online'
                : otherParticipant.status === 'away'
                ? 'Away'
                : 'Offline'}
            </p>
          </div>
        </div>
        
        <div className="flex items-center space-x-2">
          <button className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800 text-gray-500 dark:text-gray-400">
            <Phone size={20} />
          </button>
          <button className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800 text-gray-500 dark:text-gray-400">
            <Video size={20} />
          </button>
          <button className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800 text-gray-500 dark:text-gray-400">
            <Info size={20} />
          </button>
        </div>
      </div>
      
      {/* Chat messages */}
      <div className="flex-1 overflow-y-auto p-4">
        {Object.entries(messageGroups).map(([date, messages]) => (
          <div key={date}>
            <div className="flex justify-center my-4">
              <span className="text-xs bg-gray-200 dark:bg-gray-800 text-gray-500 dark:text-gray-400 px-2 py-1 rounded-full">
                {date}
              </span>
            </div>
            
            {messages.map((message, index) => {
              const isCurrentUser = message.senderId === 'current-user';
              const showAvatar = index === 0 || messages[index - 1].senderId !== message.senderId;
              
              return (
                <div
                  key={message.id}
                  className="group"
                  onDoubleClick={() => handleReplyToMessage(message.id)}
                >
                  <MessageBubble
                    message={message}
                    isCurrentUser={isCurrentUser}
                    showAvatar={showAvatar && !isCurrentUser}
                    avatar={otherParticipant.avatar}
                  />
                </div>
              );
            })}
          </div>
        ))}
        <div ref={messagesEndRef} />
      </div>
      
      {/* Typing indicator (simulated) */}
      {Math.random() > 0.7 && (
        <div className="px-4 mb-2">
          <div className="flex items-center text-gray-500 dark:text-gray-400 text-xs">
            <span className="mr-2">{otherParticipant.name} is typing</span>
            <div className="flex space-x-1">
              <span className="w-1.5 h-1.5 bg-gray-400 dark:bg-gray-600 rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></span>
              <span className="w-1.5 h-1.5 bg-gray-400 dark:bg-gray-600 rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></span>
              <span className="w-1.5 h-1.5 bg-gray-400 dark:bg-gray-600 rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></span>
            </div>
          </div>
        </div>
      )}
      
      {/* Message input */}
      <MessageInput
        onSendMessage={handleSendMessage}
        replyingTo={replyingTo}
        onCancelReply={() => setReplyingTo(null)}
      />
    </div>
  );
};

export default ChatWindow;