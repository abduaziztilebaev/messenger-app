import React from 'react';
import { Message } from '../../types';
import { formatMessageTime } from '../../utils/dateUtils';
import { Check, CheckCheck } from 'lucide-react';

interface MessageBubbleProps {
  message: Message;
  isCurrentUser: boolean;
  showAvatar?: boolean;
  avatar?: string;
}

const MessageBubble: React.FC<MessageBubbleProps> = ({
  message,
  isCurrentUser,
  showAvatar = false,
  avatar,
}) => {
  const messageTime = formatMessageTime(new Date(message.timestamp));
  
  return (
    <div
      className={`flex items-end ${
        isCurrentUser ? 'justify-end' : 'justify-start'
      } mb-4`}
    >
      {!isCurrentUser && showAvatar && (
        <div className="flex-shrink-0 mr-2">
          <img
            src={avatar}
            alt="Avatar"
            className="w-8 h-8 rounded-full"
          />
        </div>
      )}
      
      <div
        className={`relative max-w-xs md:max-w-md ${
          isCurrentUser ? 'order-1' : 'order-2'
        }`}
      >
        <div
          className={`px-4 py-2 rounded-lg ${
            isCurrentUser
              ? 'bg-blue-600 text-white rounded-br-none'
              : 'bg-gray-200 dark:bg-gray-700 text-gray-900 dark:text-gray-100 rounded-bl-none'
          }`}
        >
          {message.replyTo && (
            <div className={`text-xs mb-1 border-l-2 pl-2 ${
              isCurrentUser ? 'border-blue-300' : 'border-gray-400 dark:border-gray-500'
            }`}>
              <p className="truncate opacity-75">Replying to message</p>
            </div>
          )}
          <p className="text-sm">{message.text}</p>
        </div>
        
        <div
          className={`flex items-center mt-1 text-xs ${
            isCurrentUser ? 'justify-end' : 'justify-start'
          }`}
        >
          <span className="text-gray-500 dark:text-gray-400 mr-1">
            {messageTime}
          </span>
          
          {isCurrentUser && (
            <span className="text-gray-500 dark:text-gray-400">
              {message.read ? (
                <CheckCheck size={14} className="text-blue-500" />
              ) : (
                <Check size={14} />
              )}
            </span>
          )}
        </div>
      </div>
    </div>
  );
};

export default MessageBubble;