import React from 'react';
import ConversationItem from './ConversationItem';
import { Conversation } from '../../types';
import { useMessages } from '../../contexts/MessageContext';

interface ConversationListProps {
  conversations: Conversation[];
}

const ConversationList: React.FC<ConversationListProps> = ({ conversations }) => {
  const { activeConversation, setActiveConversation } = useMessages();
  
  // Sort conversations by last message timestamp (most recent first)
  const sortedConversations = [...conversations].sort((a, b) => {
    return new Date(b.lastMessageTimestamp).getTime() - new Date(a.lastMessageTimestamp).getTime();
  });
  
  if (sortedConversations.length === 0) {
    return (
      <div className="p-4 text-center text-gray-500 dark:text-gray-400">
        No conversations found
      </div>
    );
  }
  
  return (
    <div className="space-y-1 py-2">
      {sortedConversations.map((conversation) => (
        <ConversationItem
          key={conversation.id}
          conversation={conversation}
          isActive={activeConversation?.id === conversation.id}
          onClick={() => setActiveConversation(conversation.id)}
        />
      ))}
    </div>
  );
};

export default ConversationList;