import React, { useState, useEffect } from 'react';
import Sidebar from './components/layout/Sidebar';
import ChatWindow from './components/chat/ChatWindow';
import SettingsPanel from './components/settings/SettingsPanel';
import { ThemeProvider } from './contexts/ThemeContext';
import { UserProvider } from './contexts/UserContext';
import { MessageProvider } from './contexts/MessageContext';

function App() {
  const [showSettings, setShowSettings] = useState(false);
  const [isMobile, setIsMobile] = useState(window.innerWidth < 768);
  const [showSidebar, setShowSidebar] = useState(!isMobile);

  // Update isMobile state on window resize
  useEffect(() => {
    const handleResize = () => {
      const mobile = window.innerWidth < 768;
      setIsMobile(mobile);
      if (!mobile) {
        setShowSidebar(true);
      }
    };

    window.addEventListener('resize', handleResize);
    return () => {
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  return (
    <ThemeProvider>
      <UserProvider>
        <MessageProvider>
          <div className="h-screen flex flex-col overflow-hidden">
            {/* Mobile header with toggle */}
            {isMobile && (
              <div className="bg-white dark:bg-gray-900 border-b border-gray-200 dark:border-gray-800 p-3 flex items-center">
                <button
                  onClick={() => setShowSidebar(!showSidebar)}
                  className="p-2 rounded-md bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300"
                >
                  {showSidebar ? 'Hide Sidebar' : 'Show Sidebar'}
                </button>
                <h1 className="ml-3 text-lg font-semibold text-gray-900 dark:text-gray-100">
                  {showSidebar ? 'Conversations' : 'Chat'}
                </h1>
              </div>
            )}

            <div className="flex-1 flex overflow-hidden">
              {/* Sidebar */}
              {(showSidebar || !isMobile) && (
                <div className={`${isMobile ? 'absolute inset-0 z-10' : 'w-80'}`}>
                  <Sidebar onSettingsClick={() => setShowSettings(true)} />
                </div>
              )}

              {/* Main content */}
              <div className={`flex-1 ${isMobile && showSidebar ? 'hidden' : ''}`}>
                <ChatWindow />
              </div>
            </div>

            {/* Settings modal */}
            {showSettings && (
              <SettingsPanel onClose={() => setShowSettings(false)} />
            )}
          </div>
        </MessageProvider>
      </UserProvider>
    </ThemeProvider>
  );
}

export default App;