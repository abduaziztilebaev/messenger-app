export interface User {
  id: string;
  name: string;
  avatar: string;
  status: 'online' | 'offline' | 'away';
  lastSeen?: string;
}

export interface Message {
  id: string;
  senderId: string;
  text: string;
  timestamp: string;
  read: boolean;
  replyTo?: string;
}

export interface Conversation {
  id: string;
  participants: User[];
  messages: Message[];
  unreadCount: number;
  lastMessageTimestamp: string;
}

export interface PrivacySettings {
  showReadReceipts: boolean;
  showLastSeen: boolean;
  showActiveStatus: boolean;
}

export interface NotificationSettings {
  messageNotifications: boolean;
  soundEnabled: boolean;
  notifyWhenMentioned: boolean;
}

export type Language = 'en' | 'ru' | 'fr' | 'de' | 'es';

export interface UserSettings {
  theme: 'light' | 'dark' | 'system';
  privacy: PrivacySettings;
  notifications: NotificationSettings;
  language: Language;
  fontSize: 'small' | 'medium' | 'large';
}