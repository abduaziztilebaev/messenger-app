import { User, Conversation, Message, UserSettings } from '../types';

// Current user
export const currentUser: User = {
  id: 'current-user',
  name: 'Alex Morgan',
  avatar: 'https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg?auto=compress&cs=tinysrgb&w=150',
  status: 'online',
};

// Mock users
export const users: User[] = [
  {
    id: 'user-1',
    name: 'Sarah Johnson',
    avatar: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=150',
    status: 'online',
  },
  {
    id: 'user-2',
    name: 'Michael Chen',
    avatar: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=150',
    status: 'offline',
    lastSeen: '2023-09-10T14:30:00Z',
  },
  {
    id: 'user-3',
    name: 'Emma Wilson',
    avatar: 'https://images.pexels.com/photos/1036623/pexels-photo-1036623.jpeg?auto=compress&cs=tinysrgb&w=150',
    status: 'away',
  },
  {
    id: 'user-4',
    name: 'James Rodriguez',
    avatar: 'https://images.pexels.com/photos/2379005/pexels-photo-2379005.jpeg?auto=compress&cs=tinysrgb&w=150',
    status: 'online',
  },
  {
    id: 'user-5',
    name: 'Olivia Taylor',
    avatar: 'https://images.pexels.com/photos/733872/pexels-photo-733872.jpeg?auto=compress&cs=tinysrgb&w=150',
    status: 'offline',
    lastSeen: '2023-09-09T18:15:00Z',
  },
];

// Generate mock messages
const createMockMessages = (conversationId: string, senderId: string, receiverId: string): Message[] => {
  const messages: Message[] = [];
  const now = new Date();
  
  // Add some messages
  for (let i = 0; i < 5; i++) {
    const isCurrentUser = i % 2 === 0;
    const sender = isCurrentUser ? senderId : receiverId;
    const timestamp = new Date(now.getTime() - (5 - i) * 3600000).toISOString();
    
    messages.push({
      id: `msg-${conversationId}-${i}`,
      senderId: sender,
      text: isCurrentUser 
        ? 'Hey there! How are you doing today?' 
        : 'I\'m doing great! Just working on a new project. How about you?',
      timestamp,
      read: true,
    });
  }
  
  // Add one more recent message
  messages.push({
    id: `msg-${conversationId}-last`,
    senderId: receiverId,
    text: 'Are we still meeting for coffee tomorrow?',
    timestamp: new Date(now.getTime() - 600000).toISOString(),
    read: false,
  });
  
  return messages;
};

// Mock conversations
export const conversations: Conversation[] = users.map((user, index) => {
  const messages = createMockMessages(`conv-${index}`, currentUser.id, user.id);
  const unreadCount = messages.filter(m => m.senderId !== currentUser.id && !m.read).length;
  
  return {
    id: `conv-${index}`,
    participants: [currentUser, user],
    messages,
    unreadCount,
    lastMessageTimestamp: messages[messages.length - 1].timestamp,
  };
});

// Default user settings
export const defaultUserSettings: UserSettings = {
  theme: 'light',
  privacy: {
    showReadReceipts: true,
    showLastSeen: true,
    showActiveStatus: true,
  },
  notifications: {
    messageNotifications: true,
    soundEnabled: true,
    notifyWhenMentioned: true,
  },
  language: 'en',
  fontSize: 'medium',
};

// Language options
export const languageOptions = [
  { value: 'en', label: 'English' },
  { value: 'ru', label: 'Русский' },
  { value: 'fr', label: 'Français' },
  { value: 'de', label: 'Deutsch' },
  { value: 'es', label: 'Español' },
];